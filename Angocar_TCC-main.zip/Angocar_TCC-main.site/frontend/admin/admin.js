const API_BASE = ["5500", "5501"].includes(window.location.port)
  ? `${window.location.protocol}//${window.location.hostname}:3000/api`
  : `${window.location.origin}/api`;
const TOKEN_KEY = "angocar_token";
const USER_KEY = "angocar_usuario";
const $ = id => document.getElementById(id);
let veiculos = [];
let agendamentos = [];
let usuarios = [];

function esc(value) {
  return String(value ?? "").replace(/[&<>"']/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]);
}
function token() { return localStorage.getItem(TOKEN_KEY); }
function currentUser() { try { return JSON.parse(localStorage.getItem(USER_KEY) || "null"); } catch { return null; } }
function authHeaders(json = false) {
  const headers = {};
  if (json) headers["Content-Type"] = "application/json";
  if (token()) headers.Authorization = `Bearer ${token()}`;
  return headers;
}
async function api(path, options = {}) {
  const response = await fetch(`${API_BASE}${path}`, { ...options, headers: { ...authHeaders(Boolean(options.body) && !(options.body instanceof FormData)), ...(options.headers || {}) } });
  let data = {};
  try { data = await response.json(); } catch { /* resposta sem JSON */ }
  if (!response.ok) throw new Error(data.erro || data.message || `Erro HTTP ${response.status}`);
  return data;
}
function showMessage(id, message, error = false) {
  const el = $(id); if (!el) return;
  el.textContent = message; el.style.color = error ? "#f0b6b6" : "#d6dadd";
}
function signOut() { localStorage.removeItem(TOKEN_KEY); localStorage.removeItem(USER_KEY); location.reload(); }

async function atualizarSetupAdmin() {
  try {
    const data = await api("/usuarios/admin-setup");
    $("setupAdminNotice").hidden = !data.setupRequired;
    $("setupAdminToggle").hidden = !data.setupRequired;
    if (!data.setupRequired) $("setupAdminForm").hidden = true;
  } catch (error) {
    showMessage("loginMsg", error.message || "Não foi possível verificar a configuração inicial.", true);
  }
}

async function criarAdminInicial(event) {
  event.preventDefault();
  const senha = $("setupAdminPassword").value;
  if (senha !== $("setupAdminConfirm").value) {
    showMessage("setupAdminMsg", "As senhas não coincidem.", true);
    return;
  }

  const button = $("setupAdminSubmit");
  button.disabled = true;
  showMessage("setupAdminMsg", "A criar o primeiro administrador...");
  try {
    const data = await api("/usuarios/admin-setup", {
      method: "POST",
      body: JSON.stringify({
        nome: $("setupAdminName").value.trim(),
        email: $("setupAdminEmail").value.trim(),
        senha
      })
    });
    localStorage.setItem(TOKEN_KEY, data.token);
    localStorage.setItem(USER_KEY, JSON.stringify(data.usuario));
    await initAdmin();
  } catch (error) {
    showMessage("setupAdminMsg", error.message || "Não foi possível criar o administrador.", true);
    await atualizarSetupAdmin();
  } finally {
    button.disabled = false;
  }
}

async function login(event) {
  event.preventDefault();
  showMessage("loginMsg", "A verificar credenciais...");
  try {
    const data = await api("/usuarios/login", { method: "POST", body: JSON.stringify({ email: $("email").value.trim(), senha: $("senha").value }) });
    if (data.token) localStorage.setItem(TOKEN_KEY, data.token);
    if (data.usuario) localStorage.setItem(USER_KEY, JSON.stringify(data.usuario));
    if (data.usuario?.role !== "admin") {
      localStorage.removeItem(TOKEN_KEY); localStorage.removeItem(USER_KEY);
      throw new Error("Esta conta não tem permissões de administrador.");
    }
    await initAdmin();
  } catch (error) { showMessage("loginMsg", error.message || "Falha no login.", true); }
}

async function initAdmin() {
  const user = currentUser();
  if (!token() || user?.role !== "admin") {
    $("loginView").hidden = false;
    $("adminView").hidden = true;
    await atualizarSetupAdmin();
    return;
  }
  $("loginView").hidden = true; $("adminView").hidden = false;
  $("adminNome").textContent = user.nome || "Administrador";
  await carregarTudo();
}
async function carregarTudo() {
  try {
    const [stats, carros, bookings, people] = await Promise.all([
      api("/admin/dashboard"), api("/vehicles"), api("/admin/agendamentos"), api("/admin/usuarios")
    ]);
    $("statUsuarios").textContent = stats.usuarios ?? 0;
    $("statVeiculos").textContent = stats.veiculos ?? 0;
    $("statAgendamentos").textContent = stats.agendamentos ?? 0;
    $("statPendentes").textContent = stats.pendentes ?? 0;
    veiculos = Array.isArray(carros) ? carros : [];
    agendamentos = Array.isArray(bookings) ? bookings : [];
    usuarios = Array.isArray(people) ? people : [];
    renderVeiculos(); renderAgendamentos(); renderUsuarios();
    $("imagemVeiculo").innerHTML = '<option value="">Escolha um veículo</option>' + veiculos.map(v => `<option value="${esc(v.id)}">${esc(v.marca)} ${esc(v.modelo)}</option>`).join("");
    showMessage("globalMsg", "Dados atualizados.");
  } catch (error) {
    showMessage("globalMsg", `${error.message} — confirme se a API e a base de dados estão ligadas.`, true);
    if (/401|403|Autenticação|administrador/i.test(error.message)) signOut();
  }
}
function renderVeiculos() {
  $("veiculosTabela").innerHTML = veiculos.length ? veiculos.map(v => `<tr><td>${esc(v.id)}</td><td>${esc(v.marca)} ${esc(v.modelo)}</td><td>${esc(v.ano)}</td><td>${esc(v.categoria)}</td><td>${Number(v.preco || 0).toLocaleString("pt-PT")} Kz</td><td><button class="btn btn-outline table-action" data-edit-car="${esc(v.id)}">Editar</button><button class="btn btn-outline table-action" data-delete-car="${esc(v.id)}">Eliminar</button></td></tr>`).join("") : '<tr><td colspan="6">Ainda não existem veículos.</td></tr>';
}
function renderAgendamentos() {
  const states = ["pendente", "confirmado", "cancelado", "concluido"];
  $("agendamentosTabela").innerHTML = agendamentos.length ? agendamentos.map(a => `<tr><td>${esc(a.id)}</td><td>${esc(a.nome)}<br><small>${esc(a.email)} · ${esc(a.telefone)}<br>Morada: ${esc(a.morada || "—")}</small></td><td>${esc(a.marca)} ${esc(a.modelo)}</td><td>${esc(String(a.data).slice(0, 10))}</td><td>${esc(a.estado)}</td><td><select aria-label="Estado da marcação" id="estado-${esc(a.id)}">${states.map(s => `<option value="${s}" ${s === a.estado ? "selected" : ""}>${s}</option>`).join("")}</select><button class="btn btn-outline table-action" data-save-booking="${esc(a.id)}">Guardar</button></td></tr>`).join("") : '<tr><td colspan="6">Ainda não existem agendamentos.</td></tr>';
}
function renderUsuarios() {
  $("usuariosTabela").innerHTML = usuarios.length ? usuarios.map(u => `<tr><td>${esc(u.id)}</td><td>${esc(u.nome)}</td><td>${esc(u.email)}</td><td>${esc(u.telefone || "—")}</td><td>${esc(u.morada || "—")}</td><td>${esc(u.role)}</td><td><select aria-label="Função de ${esc(u.nome)}" id="role-${esc(u.id)}"><option value="user" ${u.role === "user" ? "selected" : ""}>user</option><option value="admin" ${u.role === "admin" ? "selected" : ""}>admin</option></select><button class="btn btn-outline table-action" data-save-role="${esc(u.id)}">Guardar</button></td></tr>`).join("") : '<tr><td colspan="7">Ainda não existem utilizadores.</td></tr>';
}
function resetVehicleForm() { $("veiculoForm").reset(); $("veiculoId").value = ""; $("guardarVeiculo").textContent = "Guardar veículo"; $("cancelarEdicao").hidden = true; }
function fillVehicleForm(id) {
  const v = veiculos.find(item => Number(item.id) === Number(id)); if (!v) return;
  $("veiculoId").value = v.id; ["marca", "modelo", "ano", "categoria", "km", "combustivel", "preco", "descricao"].forEach(key => { $(key).value = v[key] ?? ""; });
  $("guardarVeiculo").textContent = "Atualizar veículo"; $("cancelarEdicao").hidden = false; $("veiculoForm").scrollIntoView({ behavior: "smooth", block: "start" });
}
async function saveVehicle(event) {
  event.preventDefault();
  const id = $("veiculoId").value;
  const body = Object.fromEntries(["marca", "modelo", "ano", "categoria", "km", "combustivel", "preco", "descricao"].map(key => [key, $(key).value.trim()]));
  body.ano = Number(body.ano); body.preco = Number(body.preco);
  try {
    await api(id ? `/admin/veiculos/${id}` : "/admin/veiculos", { method: id ? "PUT" : "POST", body: JSON.stringify(body) });
    resetVehicleForm(); await carregarTudo(); showMessage("globalMsg", id ? "Veículo atualizado." : "Veículo adicionado.");
  } catch (error) { showMessage("globalMsg", error.message, true); }
}
async function deleteVehicle(id) {
  if (!confirm("Tem a certeza de que deseja eliminar este veículo?")) return;
  try { await api(`/admin/veiculos/${id}`, { method: "DELETE" }); await carregarTudo(); showMessage("globalMsg", "Veículo eliminado."); }
  catch (error) { showMessage("globalMsg", error.message, true); }
}
async function saveBooking(id) {
  try { await api(`/admin/agendamentos/${id}`, { method: "PATCH", body: JSON.stringify({ estado: $(`estado-${id}`).value }) }); await carregarTudo(); showMessage("globalMsg", "Estado do agendamento atualizado."); }
  catch (error) { showMessage("globalMsg", error.message, true); }
}
async function saveRole(id) {
  try { await api(`/admin/usuarios/${id}/role`, { method: "PATCH", body: JSON.stringify({ role: $(`role-${id}`).value }) }); await carregarTudo(); showMessage("globalMsg", "Função do utilizador atualizada."); }
  catch (error) { showMessage("globalMsg", error.message, true); }
}

document.addEventListener("DOMContentLoaded", () => {
  $("loginForm").addEventListener("submit", login);
  $("setupAdminToggle").addEventListener("click", () => { $("setupAdminForm").hidden = !$("setupAdminForm").hidden; });
  $("setupAdminForm").addEventListener("submit", criarAdminInicial);
  $("sairBtn").addEventListener("click", signOut);
  $("recarregarBtn").addEventListener("click", carregarTudo);
  $("veiculoForm").addEventListener("submit", saveVehicle);
  $("imagemForm").addEventListener("submit", async event => {
    event.preventDefault();
    const id = $("imagemVeiculo").value;
    const file = $("imagemArquivo").files[0];
    if (!id || !file) return showMessage("globalMsg", "Escolha o veículo e a imagem.", true);
    const form = new FormData(); form.append("imagem", file);
    try { await api(`/vehicles/${id}/images`, { method: "POST", body: form }); $("imagemForm").reset(); await carregarTudo(); showMessage("globalMsg", "Imagem enviada para o banco de dados."); }
    catch (error) { showMessage("globalMsg", error.message, true); }
  });
  $("videoForm").addEventListener("submit", async event => {
    event.preventDefault();
    const file = $("videoArquivo").files[0]; if (!file) return;
    const form = new FormData(); form.append("video", file);
    try { await api("/media/video", { method: "POST", body: form }); $("videoForm").reset(); showMessage("globalMsg", "Vídeo principal atualizado."); }
    catch (error) { showMessage("globalMsg", error.message, true); }
  });
  $("cancelarEdicao").addEventListener("click", resetVehicleForm);
  document.querySelectorAll("[data-tab]").forEach(button => button.addEventListener("click", () => {
    document.querySelectorAll("[data-tab]").forEach(b => b.classList.toggle("active", b === button));
    ["veiculos", "agendamentos", "usuarios", "multimedia"].forEach(tab => { $(`tab-${tab}`).hidden = tab !== button.dataset.tab; });
  }));
  document.addEventListener("click", event => {
    const target = event.target.closest("button"); if (!target) return;
    if (target.dataset.editCar) fillVehicleForm(target.dataset.editCar);
    if (target.dataset.deleteCar) deleteVehicle(target.dataset.deleteCar);
    if (target.dataset.saveBooking) saveBooking(target.dataset.saveBooking);
    if (target.dataset.saveRole) saveRole(target.dataset.saveRole);
  });
  initAdmin();
});
