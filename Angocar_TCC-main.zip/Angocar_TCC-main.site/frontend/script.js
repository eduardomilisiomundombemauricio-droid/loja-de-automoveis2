const API_URL = ["5500", "5501"].includes(window.location.port)
  ? `${window.location.protocol}//${window.location.hostname}:3000/api`
  : `${window.location.origin}/api`;
const TOKEN_KEY = "angocar_token";
const USER_KEY = "angocar_usuario";

let veiculosBD = [];
let indicesCarrossel = {};
let paginaVeiculos = 0;
const VEICULOS_POR_PAGINA = 12;

const $ = id => document.getElementById(id);
const formatarPreco = valor => new Intl.NumberFormat("pt-PT").format(Number(valor) || 0) + " Kz";
const urlImagem = caminho => new URL(caminho, API_URL).href;

function token() { return localStorage.getItem(TOKEN_KEY); }
function usuarioAtual() { try { return JSON.parse(localStorage.getItem(USER_KEY) || "null"); } catch { return null; } }
function guardarSessao(data) {
  if (data?.token) localStorage.setItem(TOKEN_KEY, data.token);
  if (data?.usuario) localStorage.setItem(USER_KEY, JSON.stringify(data.usuario));
}
function limparSessao() { localStorage.removeItem(TOKEN_KEY); localStorage.removeItem(USER_KEY); }
function headers(json = false) { const h = {}; if (json) h["Content-Type"] = "application/json"; if (token()) h.Authorization = `Bearer ${token()}`; return h; }
async function api(path, options = {}) {
  let res;
  try {
    const isFormData = options.body instanceof FormData;
    res = await fetch(`${API_URL}${path}`, { ...options, headers: { ...headers(Boolean(options.body) && !isFormData), ...(options.headers || {}) } });
  } catch {
    throw new Error("Não foi possível ligar à API. Confirme se o servidor do site e a API estão em execução.");
  }
  let data = null; try { data = await res.json(); } catch { data = {}; }
  if (res.status === 401) { limparSessao(); atualizarBotaoLogin(); }
  if (!res.ok) throw new Error(data.erro || data.message || "Erro na API.");
  return data;
}

function mostrarSecao(id) {
  const secao = $(id);
  if (!secao || !secao.matches("main > section")) return false;

  document.querySelectorAll("main > section").forEach(item => item.classList.remove("secao-ativa"));
  secao.classList.add("secao-ativa");
  if (id === "inicio") document.querySelector("main > section.stats")?.classList.add("secao-ativa");
  document.body.classList.add("modo-seccao");
  document.querySelectorAll('nav a[href^="#"]').forEach(link => link.classList.toggle("active", link.hash === `#${id}`));
  if (id === "agendamentos") carregarMeusAgendamentos();
  return true;
}

document.querySelectorAll('a[href^="#"]').forEach(link => link.addEventListener("click", event => {
  const id = event.currentTarget.hash.slice(1);
  if (!mostrarSecao(id)) return;
  event.preventDefault();
  window.scrollTo({ top: 0, behavior: "smooth" });
}));

if (!mostrarSecao(window.location.hash.slice(1))) mostrarSecao("inicio");

async function carregarVeiculos() {
  try { veiculosBD = await api("/vehicles"); preencherSelectVeiculos(); mostrarVeiculos(); }
  catch (e) { console.error(e); $("listaVeiculos")?.replaceChildren(Object.assign(document.createElement("p"), { className: "sem-resultados", textContent: e.message })); }
}
function preencherSelectVeiculos() { const s = $("veiculoTestDrive"); if (!s) return; s.innerHTML = '<option value="">Escolha um veículo</option>' + veiculosBD.map(v => `<option value="${v.id}">${v.marca} ${v.modelo}</option>`).join(""); }
function agendarCarroDirecto(id) {
  if (!verificarLoginParaTestDrive()) return;
  preencherSelectVeiculos();
  const selecao = $("veiculoTestDrive");
  if (selecao) selecao.value = String(id);
  abrirModal("modalTestDrive");
}
function mostrarVeiculos() {
  const lista = $("listaVeiculos"); if (!lista) return;
  const pesquisa = ($("pesquisaVeiculo")?.value || "").trim().toLowerCase();
  const categoria = $("filtroCategoria")?.value || "";
  const preco = Number($("filtroPreco")?.value) || Infinity;
  const encontrados = veiculosBD.filter(v => `${v.marca} ${v.modelo}`.toLowerCase().includes(pesquisa) && (!categoria || v.categoria === categoria) && Number(v.preco) <= preco);
  const totalPaginas = Math.ceil(encontrados.length / VEICULOS_POR_PAGINA);
  paginaVeiculos = Math.min(paginaVeiculos, Math.max(totalPaginas - 1, 0));
  const inicio = paginaVeiculos * VEICULOS_POR_PAGINA;
  const pagina = encontrados.slice(inicio, inicio + VEICULOS_POR_PAGINA);
  if (!encontrados.length) {
    lista.innerHTML = '<p class="sem-resultados">Não foram encontrados veículos com esses critérios.</p>';
    $("paginacaoVeiculos").replaceChildren();
    return;
  }
  lista.innerHTML = pagina.map(v => {
    indicesCarrossel[v.id] ??= 0;
    const possuiImagens = Boolean(v.imagens?.length);
    const imgs = possuiImagens ? v.imagens.map(urlImagem) : ["imagens/carro-hero.webp"];
    const indiceImagem = possuiImagens ? indicesCarrossel[v.id] : 0;
    const contadorImagens = possuiImagens ? `${indiceImagem + 1}/${imgs.length}` : "Sem fotos";
    return `<article class="veiculo"><div class="veiculo-imagem"><button class="seta-carrossel seta-esquerda" type="button" aria-label="Foto anterior" onclick="mudarImagem(${v.id},-1)" ${indiceImagem === 0 ? "disabled" : ""}>&#10094;</button><img id="img-veiculo-${v.id}" src="${imgs[indiceImagem] || imgs[0]}" alt="${v.marca} ${v.modelo}" loading="lazy" decoding="async" onerror="this.src='imagens/carro-hero.webp'"><span class="contador-carrossel">${contadorImagens}</span><button class="seta-carrossel seta-direita" type="button" aria-label="Próxima foto" onclick="mudarImagem(${v.id},1)" ${indiceImagem >= imgs.length - 1 ? "disabled" : ""}>&#10095;</button></div><div class="veiculo-info"><h3>${v.marca} ${v.modelo}</h3><p>Ano: ${v.ano} · ${v.categoria}</p><p>${v.km || ""} · ${v.combustivel || ""}</p><div class="preco">${formatarPreco(v.preco)}</div><button class="btn btn-primary" type="button" onclick="verDetalhes(${v.id})">Ver detalhes</button><button class="btn btn-secondary" type="button" onclick="agendarCarroDirecto(${v.id})">Test drive</button></div></article>`;
  }).join("");
  const paginacao = $("paginacaoVeiculos");
  if (paginacao) {
    paginacao.innerHTML = totalPaginas > 1
      ? `<button class="btn btn-secondary" type="button" data-pagina="${paginaVeiculos - 1}" ${paginaVeiculos === 0 ? "disabled" : ""}>Anterior</button><span>Mostrando ${inicio + 1}–${Math.min(inicio + pagina.length, encontrados.length)} de ${encontrados.length}</span><button class="btn btn-secondary" type="button" data-pagina="${paginaVeiculos + 1}" ${paginaVeiculos >= totalPaginas - 1 ? "disabled" : ""}>Próxima</button>`
      : "";
  }
}
function mudarImagem(id, direcao) { const v = veiculosBD.find(x => Number(x.id) === Number(id)); if (!v?.imagens?.length) return; indicesCarrossel[id] = (indicesCarrossel[id] + direcao + v.imagens.length) % v.imagens.length; const img = $(`img-veiculo-${id}`); if (img) { const container = img.closest(".veiculo-imagem"); img.src = urlImagem(v.imagens[indicesCarrossel[id]]); const contador = container?.querySelector(".contador-carrossel"); if (contador) contador.textContent = `${indicesCarrossel[id] + 1}/${v.imagens.length}`; const anterior = container?.querySelector(".seta-esquerda"); const proxima = container?.querySelector(".seta-direita"); if (anterior) anterior.disabled = indicesCarrossel[id] === 0; if (proxima) proxima.disabled = indicesCarrossel[id] >= v.imagens.length - 1; } }
function verDetalhes(id) { const v = veiculosBD.find(x => Number(x.id) === Number(id)); if (!v) return; alert(`VEÍCULO: ${v.marca} ${v.modelo}\nAno: ${v.ano}\nCategoria: ${v.categoria}\nQuilometragem: ${v.km || "-"}\nCombustível: ${v.combustivel || "-"}\nPreço: ${formatarPreco(v.preco)}\n\n${v.descricao || ""}`); }

$("pesquisaVeiculo")?.addEventListener("input", () => { paginaVeiculos = 0; mostrarVeiculos(); });
$("filtroCategoria")?.addEventListener("change", () => { paginaVeiculos = 0; mostrarVeiculos(); });
$("filtroPreco")?.addEventListener("change", () => { paginaVeiculos = 0; mostrarVeiculos(); });
$("paginacaoVeiculos")?.addEventListener("click", event => {
  const botao = event.target.closest("[data-pagina]");
  if (!botao || botao.disabled) return;
  paginaVeiculos = Number(botao.dataset.pagina);
  mostrarVeiculos();
});
function abrirModal(id) { $(id)?.classList.add("aberto"); }
function fecharModal(id) { $(id)?.classList.remove("aberto"); }

$("botaoLogin")?.addEventListener("click", e => { e.preventDefault(); if (token()) { if (confirm("Deseja terminar a sessão?")) { limparSessao(); atualizarBotaoLogin(); } } else abrirModal("modalLogin"); });
$("botaoTestDrive")?.addEventListener("click", () => verificarLoginParaTestDrive() && abrirModal("modalTestDrive"));
document.querySelectorAll(".acaoTestDrive").forEach(b => b.addEventListener("click", () => verificarLoginParaTestDrive() && abrirModal("modalTestDrive")));
document.querySelectorAll("[data-fechar]").forEach(b => b.addEventListener("click", () => fecharModal(b.dataset.fechar)));

let modoLogin = "entrar";
function atualizarModoLogin() {
  const registar = modoLogin === "registar";
  const nome = $("nomeLogin");
  const confirmar = $("confirmarSenhaLogin");
  if ($("tituloLogin")) $("tituloLogin").textContent = registar ? "Criar conta ANGOCAR" : "Faça o login";
  if ($("descricaoLogin")) $("descricaoLogin").textContent = registar ? "Crie a sua conta para guardar os seus agendamentos." : "Entre na sua conta ANGOCAR.";
  if (nome) { nome.hidden = !registar; nome.required = registar; }
  if (confirmar) { confirmar.hidden = !registar; confirmar.required = registar; }
  if ($("senhaLogin")) { $("senhaLogin").minLength = registar ? 8 : 1; $("senhaLogin").autocomplete = registar ? "new-password" : "current-password"; $("senhaLogin").placeholder = registar ? "Palavra-passe (mínimo 8 caracteres)" : "Palavra-passe"; }
  if ($("enviarLogin")) $("enviarLogin").textContent = registar ? "Criar conta" : "Entrar";
  if ($("textoAlternar")) $("textoAlternar").textContent = registar ? "Já tem conta?" : "Ainda não tem conta?";
  if ($("alternarLogin")) $("alternarLogin").textContent = registar ? "Entrar" : "Criar conta";
  const aviso = $("avisoLogin"); if (aviso) { aviso.textContent = ""; aviso.classList.remove("visivel"); }
}
$("alternarLogin")?.addEventListener("click", () => { modoLogin = modoLogin === "entrar" ? "registar" : "entrar"; atualizarModoLogin(); });

$("formLogin")?.addEventListener("submit", async e => {
  e.preventDefault();
  const aviso = $("avisoLogin");
  const botao = $("enviarLogin");
  const email = ($("emailLogin")?.value || "").trim().toLowerCase();
  const senha = $("senhaLogin")?.value || "";
  const nome = ($("nomeLogin")?.value || "").trim();
  const confirmar = $("confirmarSenhaLogin")?.value || "";
  const mostrarAviso = mensagem => { if (aviso) { aviso.textContent = mensagem; aviso.classList.add("visivel"); } };
  if (!email || !senha || (modoLogin === "registar" && (!nome || !confirmar))) { mostrarAviso("Preencha todos os campos obrigatórios."); return; }
  if (modoLogin === "registar" && nome.length < 2) { mostrarAviso("O nome deve ter pelo menos 2 caracteres."); return; }
  if (modoLogin === "registar" && senha.length < 8) { mostrarAviso("A palavra-passe deve ter pelo menos 8 caracteres."); return; }
  if (modoLogin === "registar" && senha !== confirmar) { mostrarAviso("As palavras-passe não coincidem."); return; }
  if (botao) { botao.disabled = true; botao.textContent = modoLogin === "registar" ? "A criar conta..." : "A entrar..."; }
  try {
    const data = await api(modoLogin === "registar" ? "/usuarios" : "/usuarios/login", {
      method: "POST",
      body: JSON.stringify(modoLogin === "registar" ? { nome, email, senha } : { email, senha })
    });
    guardarSessao(data);
    mostrarAviso(modoLogin === "registar" ? "Conta criada com sucesso! Já tem sessão iniciada." : "Sessão iniciada com sucesso.");
    atualizarBotaoLogin();
    if ($("agendamentos")?.classList.contains("secao-ativa")) carregarMeusAgendamentos();
    setTimeout(() => fecharModal("modalLogin"), 900);
  } catch (err) {
    mostrarAviso(err.message || "Não foi possível concluir o pedido. Verifique se a API está a funcionar.");
  } finally {
    if (botao) { botao.disabled = false; atualizarModoLoginLabel(); }
  }
});
function atualizarModoLoginLabel() { if ($("enviarLogin")) $("enviarLogin").textContent = modoLogin === "registar" ? "Criar conta" : "Entrar"; }

function atualizarBotaoLogin() { const b = $("botaoLogin"); if (!b) return; const u = usuarioAtual(); b.textContent = u ? `Olá, ${u.nome.split(" ")[0]} · Sair` : "Faça o login"; }
function verificarLoginParaTestDrive() { if (!token()) { alert("Precisas de iniciar sessão para agendar um Test Drive."); abrirModal("modalLogin"); return false; } return true; }

$("dataTestDrive")?.setAttribute("min", new Date().toISOString().split("T")[0]);
$("formTestDrive")?.addEventListener("submit", async e => {
  e.preventDefault(); if (!verificarLoginParaTestDrive()) return; const aviso = $("avisoTestDrive"); const payload = { veiculo_id: Number($("veiculoTestDrive")?.value), nome: $("nomeTestDrive")?.value.trim(), telefone: $("telefoneTestDrive")?.value.trim(), data: $("dataTestDrive")?.value };
  if (!payload.veiculo_id || !payload.nome || !payload.telefone || !payload.data) { aviso.textContent = "Preencha todos os dados do agendamento."; aviso.classList.add("visivel"); return; }
  try { await api("/agendamentos", { method: "POST", body: JSON.stringify(payload) }); aviso.textContent = "Agendamento realizado com sucesso!"; aviso.classList.add("visivel"); setTimeout(() => fecharModal("modalTestDrive"), 1200); } catch (err) { aviso.textContent = err.message; aviso.classList.add("visivel"); }
});

document.addEventListener("DOMContentLoaded", () => { carregarVeiculos(); atualizarBotaoLogin(); carregarVideoPrincipal(); });

// ==========================================
// CONSULTAS DO UTILIZADOR
// ==========================================

async function consultarMeuPerfil() {
  if (!token()) return null;
  return api("/usuarios/me");
}

async function consultarMeusAgendamentos() {
  if (!token()) return [];
  return api("/agendamentos/me");
}

async function carregarMeusAgendamentos() {
  const lista = $("listaAgendamentos");
  if (!lista) return;
  if (!token()) {
    lista.innerHTML = '<p class="sem-resultados">Entre na sua conta para consultar os seus agendamentos.</p><button class="btn btn-primary" type="button" id="entrarParaVerAgendamentos">Entrar</button>';
    $("entrarParaVerAgendamentos")?.addEventListener("click", () => abrirModal("modalLogin"));
    return;
  }

  lista.innerHTML = '<p class="sem-resultados">A carregar agendamentos...</p>';
  try {
    const agendamentos = await consultarMeusAgendamentos();
    if (!agendamentos.length) {
      lista.innerHTML = '<p class="sem-resultados">Ainda não tem agendamentos.</p>';
      return;
    }

    const formatarData = data => new Intl.DateTimeFormat("pt-PT", { dateStyle: "long", timeZone: "UTC" }).format(new Date(data));
    lista.innerHTML = `<div class="lista-agendamentos">${agendamentos.map(item => {
      const artigo = document.createElement("article");
      artigo.className = "agendamento-item";
      const titulo = document.createElement("h3");
      titulo.textContent = `${item.marca} ${item.modelo}`;
      const data = document.createElement("p");
      data.textContent = `Data: ${formatarData(item.data)}`;
      const estado = document.createElement("p");
      estado.textContent = `Estado: ${item.estado}`;
      artigo.append(titulo, data, estado);
      return artigo.outerHTML;
    }).join("")}</div>`;
  } catch (err) {
    lista.innerHTML = "";
    const erro = document.createElement("p");
    erro.className = "sem-resultados";
    erro.textContent = err.message;
    const tentarNovamente = document.createElement("button");
    tentarNovamente.className = "btn btn-secondary";
    tentarNovamente.type = "button";
    tentarNovamente.textContent = "Tentar novamente";
    tentarNovamente.addEventListener("click", carregarMeusAgendamentos);
    lista.append(erro, tentarNovamente);
  }
}

function carregarVideoPrincipal() {
  const video = document.getElementById("videoPrincipal");
  if (!video) return;
  const fallback = video.dataset.fallbackSrc;
  video.addEventListener("error", () => {
    if (fallback && !video.dataset.fallbackTried) {
      video.dataset.fallbackTried = "true";
      video.src = fallback;
      video.load();
    }
  }, { once: true });
  video.src = `${API_URL}/media/video`;
  video.load();
}
