// URL DO BACKEND — mantida conforme solicitado
const API_URL = "https://teu-backend-no-render.onrender.com/api";

const linkInicio = document.getElementById("linkInicio");
const linkVeiculos = document.getElementById("linkVeiculos");
let veiculosBD = [];
let indicesCarrossel = {};
let modoLogin = "entrar";

const formatarPreco = valor => new Intl.NumberFormat("pt-PT").format(Number(valor) || 0) + " Kz";
const listaVeiculos = document.getElementById("listaVeiculos");

function mostrarInicio(event) {
    if (event) event.preventDefault();
    document.body.classList.remove("modo-veiculos");
    linkInicio?.classList.add("active");
    linkVeiculos?.classList.remove("active");
    window.scrollTo({ top: 0, behavior: "smooth" });
}

function abrirAbaVeiculos(event) {
    if (event) event.preventDefault();
    document.body.classList.add("modo-veiculos");
    linkInicio?.classList.remove("active");
    linkVeiculos?.classList.add("active");
    window.scrollTo({ top: 0, behavior: "smooth" });
}

linkInicio?.addEventListener("click", mostrarInicio);
document.querySelectorAll('a[href="#veiculos"]').forEach(link => link.addEventListener("click", abrirAbaVeiculos));

function mostrarAviso(elemento, mensagem) {
    if (!elemento) return;
    elemento.textContent = mensagem;
    elemento.classList.add("visivel");
}

async function lerResposta(res) {
    const texto = await res.text();
    if (!texto) return {};
    try { return JSON.parse(texto); } catch { return { mensagem: texto }; }
}

async function carregarVeiculos() {
    try {
        const resposta = await fetch(`${API_URL}/vehicles`);
        const dados = await lerResposta(resposta);
        if (!resposta.ok) throw new Error(dados.erro || dados.mensagem || `Servidor respondeu ${resposta.status}`);
        if (!Array.isArray(dados)) throw new Error("Formato de veículos inválido recebido do servidor.");
        veiculosBD = dados;

        const select = document.getElementById("veiculoTestDrive");
        if (select) {
            select.innerHTML = '<option value="">Escolha um veículo</option>' +
                veiculosBD.map(v => `<option value="${v.id}">${v.marca || ""} ${v.modelo || ""}</option>`).join("");
        }
        mostrarVeiculos();
    } catch (erro) {
        console.error("Erro ao carregar veículos:", erro);
        if (listaVeiculos) listaVeiculos.innerHTML = '<p class="sem-resultados">Não foi possível carregar os veículos. Verifique o servidor e tente novamente.</p>';
    }
}

function mostrarVeiculos() {
    if (!listaVeiculos) return;
    const pesquisa = document.getElementById("pesquisaVeiculo")?.value.trim().toLowerCase() || "";
    const categoria = document.getElementById("filtroCategoria")?.value || "";
    const precoMaximo = Number(document.getElementById("filtroPreco")?.value) || Infinity;

    const encontrados = veiculosBD.filter(v => {
        const nome = `${v.marca || ""} ${v.modelo || ""}`.toLowerCase();
        return nome.includes(pesquisa) && (!categoria || v.categoria === categoria) && Number(v.preco) <= precoMaximo;
    });

    if (!encontrados.length) {
        listaVeiculos.innerHTML = '<p class="sem-resultados">Não foram encontrados veículos com esses critérios.</p>';
        return;
    }

    listaVeiculos.innerHTML = encontrados.map(v => {
        if (!(v.id in indicesCarrossel)) indicesCarrossel[v.id] = 0;
        const imagens = Array.isArray(v.imagens) && v.imagens.length ? v.imagens : ["imagens/11452734.png"];
        const imgAtual = imagens[indicesCarrossel[v.id]] || imagens[0];
        return `
            <article class="veiculo">
                <div class="veiculo-imagem">
                    ${imagens.length > 1 ? `<button class="seta-carrossel seta-esquerda" type="button" onclick="mudarImagem(${Number(v.id)}, -1)">&#10094;</button>` : ""}
                    <img id="img-veiculo-${Number(v.id)}" src="${imgAtual}" alt="${v.marca || ""} ${v.modelo || ""}" onerror="this.onerror=null;this.src='imagens/11452734.png';">
                    ${imagens.length > 1 ? `<button class="seta-carrossel seta-direita" type="button" onclick="mudarImagem(${Number(v.id)}, 1)">&#10095;</button>` : ""}
                </div>
                <div class="veiculo-info">
                    <h3>${v.marca || ""} ${v.modelo || ""}</h3>
                    <p>Ano: ${v.ano || "Não informado"} · ${v.categoria || "Não informado"}</p>
                    <p>${v.km || "Quilometragem não informada"} · ${v.combustivel || "Combustível não informado"}</p>
                    <div class="preco">${formatarPreco(v.preco)}</div>
                    <button class="btn btn-primary" type="button" onclick="verDetalhes(${Number(v.id)})">Ver detalhes</button>
                    <button class="btn btn-secondary" type="button" onclick="agendarCarroDirecto(${Number(v.id)})">Test drive</button>
                </div>
            </article>`;
    }).join("");
}

function mudarImagem(id, direcao) {
    const v = veiculosBD.find(item => Number(item.id) === Number(id));
    if (!v || !Array.isArray(v.imagens) || v.imagens.length <= 1) return;
    indicesCarrossel[id] = (indicesCarrossel[id] + direcao + v.imagens.length) % v.imagens.length;
    const imagem = document.getElementById(`img-veiculo-${id}`);
    if (imagem) imagem.src = v.imagens[indicesCarrossel[id]];
}

function verDetalhes(id) {
    const v = veiculosBD.find(item => Number(item.id) === Number(id));
    const caixa = document.getElementById("detalhesVeiculo");
    if (!v || !caixa) return;
    document.getElementById("detalhesTitulo").textContent = `${v.marca || ""} ${v.modelo || ""}`.trim() || "Detalhes do veículo";
    caixa.innerHTML = `<div class="detalhes-lista">
        <div class="detalhe-item"><strong>Ano:</strong> ${v.ano || "Não informado"}</div>
        <div class="detalhe-item"><strong>Categoria:</strong> ${v.categoria || "Não informada"}</div>
        <div class="detalhe-item"><strong>Quilometragem:</strong> ${v.km || "Não informada"}</div>
        <div class="detalhe-item"><strong>Combustível:</strong> ${v.combustivel || "Não informado"}</div>
        <div class="detalhe-item"><strong>Preço:</strong> ${formatarPreco(v.preco)}</div>
    </div>`;
    abrirModal("modalDetalhesVeiculo");
}

function agendarCarroDirecto(id) {
    if (!verificarLoginParaTestDrive()) return;
    const select = document.getElementById("veiculoTestDrive");
    if (select) select.value = String(id);
    abrirModal("modalTestDrive");
}

document.getElementById("pesquisaVeiculo")?.addEventListener("input", mostrarVeiculos);
document.getElementById("filtroCategoria")?.addEventListener("change", mostrarVeiculos);
document.getElementById("filtroPreco")?.addEventListener("change", mostrarVeiculos);

function abrirModal(id) { document.getElementById(id)?.classList.add("aberto"); }
function fecharModal(id) { document.getElementById(id)?.classList.remove("aberto"); }
document.querySelectorAll("[data-fechar]").forEach(b => b.addEventListener("click", () => fecharModal(b.dataset.fechar)));
document.querySelectorAll(".fundo-modal").forEach(m => m.addEventListener("click", e => { if (e.target === m) m.classList.remove("aberto"); }));

const btnLogin = document.getElementById("botaoLogin");
btnLogin?.addEventListener("click", e => {
    e.preventDefault();
    const sessao = obterSessao();
    if (sessao?.nome) abrirMenuUtilizador();
    else abrirModal("modalLogin");
});

function obterSessao() {
    try { return JSON.parse(localStorage.getItem("angocar_sessao_demo") || "null"); }
    catch { localStorage.removeItem("angocar_sessao_demo"); return null; }
}

function abrirMenuUtilizador() {
    const menu = document.getElementById("menuUtilizador");
    if (menu) menu.hidden = false;
}
function fecharMenuUtilizador() {
    const menu = document.getElementById("menuUtilizador");
    if (menu) menu.hidden = true;
}

document.getElementById("btnCancelarMenu")?.addEventListener("click", fecharMenuUtilizador);
document.getElementById("btnSair")?.addEventListener("click", () => {
    localStorage.removeItem("angocar_sessao_demo");
    fecharMenuUtilizador();
    atualizarBotaoLogin();
});
document.getElementById("btnAlterarConta")?.addEventListener("click", () => {
    fecharMenuUtilizador();
    alert("A edição da conta deve ser ligada à rota de atualização de utilizador do teu backend.");
});

document.getElementById("botaoTestDrive")?.addEventListener("click", () => { if (verificarLoginParaTestDrive()) abrirModal("modalTestDrive"); });
document.querySelectorAll(".acaoTestDrive").forEach(b => b.addEventListener("click", () => { if (verificarLoginParaTestDrive()) abrirModal("modalTestDrive"); }));

const btnAlternar = document.getElementById("alternarLogin");
btnAlternar?.addEventListener("click", () => {
    modoLogin = modoLogin === "entrar" ? "registar" : "entrar";
    const registar = modoLogin === "registar";
    document.getElementById("tituloLogin").textContent = registar ? "Criar conta" : "Faça o login";
    const nome = document.getElementById("nomeLogin");
    nome.hidden = !registar;
    nome.required = registar;
    document.getElementById("enviarLogin").textContent = registar ? "Criar conta" : "Entrar";
    document.getElementById("textoAlternar").textContent = registar ? "Já tem conta?" : "Ainda não tem conta?";
    btnAlternar.textContent = registar ? "Entrar" : "Criar conta";
});

const formLogin = document.getElementById("formLogin");
formLogin?.addEventListener("submit", async e => {
    e.preventDefault();
    const aviso = document.getElementById("avisoLogin");
    const email = document.getElementById("emailLogin")?.value.trim() || "";
    const senha = document.getElementById("senhaLogin")?.value || "";
    const nome = document.getElementById("nomeLogin")?.value.trim() || "";
    const rota = modoLogin === "registar" ? "/usuarios" : "/users/login";
    const corpo = modoLogin === "registar" ? { nome, email, senha } : { email, senha };

    try {
        const res = await fetch(`${API_URL}${rota}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(corpo) });
        const dados = await lerResposta(res);
        if (!res.ok) { mostrarAviso(aviso, dados.erro || dados.mensagem || "Não foi possível concluir a operação."); return; }
        if (!dados || typeof dados !== "object") { mostrarAviso(aviso, "O servidor devolveu uma resposta inválida."); return; }
        localStorage.setItem("angocar_sessao_demo", JSON.stringify(dados));
        mostrarAviso(aviso, modoLogin === "registar" ? "Conta criada com sucesso." : "Login efetuado com sucesso.");
        atualizarBotaoLogin();
        setTimeout(() => fecharModal("modalLogin"), 700);
    } catch (err) {
        console.error(err);
        mostrarAviso(aviso, "Não foi possível comunicar com o servidor. Tente novamente.");
    }
});

function atualizarBotaoLogin() {
    const botao = document.getElementById("botaoLogin");
    const sessao = obterSessao();
    if (!botao) return;
    botao.textContent = sessao?.nome ? `Olá, ${sessao.nome.split(" ")[0]}` : "Faça o login";
}
const actualizarBotaoLogin = atualizarBotaoLogin;

function verificarLoginParaTestDrive() {
    if (!obterSessao()) {
        alert("Precisas de iniciar sessão para agendar um Test Drive.");
        abrirModal("modalLogin");
        return false;
    }
    return true;
}

const elData = document.getElementById("dataTestDrive");
if (elData) elData.min = new Date().toISOString().split("T")[0];

const formTestDrive = document.getElementById("formTestDrive");
formTestDrive?.addEventListener("submit", async e => {
    e.preventDefault();
    const aviso = document.getElementById("avisoTestDrive");
    const sessao = obterSessao();
    if (!sessao) { mostrarAviso(aviso, "A sessão expirou. Entre novamente."); abrirModal("modalLogin"); return; }

    const veiculoId = Number(document.getElementById("veiculoTestDrive")?.value || 0);
    const data = document.getElementById("dataTestDrive")?.value || "";
    if (!veiculoId || !data) { mostrarAviso(aviso, "Escolha o veículo e a data do Test Drive."); return; }

    const payload = {
        usuario_id: sessao.id || null,
        nome: document.getElementById("nomeTestDrive")?.value.trim() || sessao.nome || "",
        telefone: document.getElementById("telefoneTestDrive")?.value.trim() || "",
        veiculo_id: veiculoId,
        data
    };

    try {
        const res = await fetch(`${API_URL}/agendamentos`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
        const dados = await lerResposta(res);
        if (!res.ok) { mostrarAviso(aviso, dados.erro || dados.mensagem || "Não foi possível criar a marcação."); return; }
        mostrarAviso(aviso, "Agendamento enviado com sucesso.");
        formTestDrive.reset();
        setTimeout(() => fecharModal("modalTestDrive"), 1000);
    } catch (err) {
        console.error(err);
        mostrarAviso(aviso, "Não foi possível enviar a marcação. Verifique a ligação ao servidor.");
    }
});

// Evita enviar o formulário de contacto como se fosse uma página normal.
document.getElementById("formContacto")?.addEventListener("submit", e => {
    e.preventDefault();
    mostrarAviso(document.getElementById("avisoContacto"), "Mensagem preparada. O envio ao servidor pode ser ligado à rota de contacto quando estiver disponível.");
});

document.addEventListener("DOMContentLoaded", () => {
    carregarVeiculos();
    atualizarBotaoLogin();
});
