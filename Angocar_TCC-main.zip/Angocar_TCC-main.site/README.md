# ANGOCAR PRO

Aplicação web com frontend em HTML/CSS/JavaScript e API em Node.js + Express + TypeScript + MySQL.

## Executar backend e banco com Docker

Para executar pelo Docker, basta ter Docker Desktop com Docker Compose; não é preciso instalar Node.js nem MySQL no computador.

1. Na raiz do projeto, confirme que existe um arquivo `.env` com os valores abaixo. Se ainda não existir, crie-o a partir do exemplo e defina senhas fortes e únicas:

```powershell
Copy-Item .env.docker.example .env
```

2. Inicie o site, o backend e o banco:

```powershell
docker compose up --build -d
```

3. No computador que executa os containers, acesse `http://localhost:8080/`; o painel fica em `http://localhost:8080/admin/`. Para os parceiros na mesma rede, descubra o endereço IPv4 desse computador com `ipconfig` e acesse `http://ENDERECO-IP:8080/` (por exemplo, `http://192.168.1.25:8080/`).

O Compose inicia o frontend Nginx, a API e o MySQL. O Nginx serve os ficheiros do site e encaminha `/api` para o container da API; o backend e o MySQL não ficam expostos à rede local. Os computadores precisam estar na mesma rede, e o Firewall do Windows no computador anfitrião pode precisar permitir ligações de entrada na porta TCP 8080 em redes privadas. Na primeira inicialização, o schema de `backend/database/schema.sql` é aplicado automaticamente. Os dados ficam no volume Docker `angocar_data` do computador que executa os containers e são preservados ao parar com `docker compose down`.

Para trabalho colaborativo, basta um computador executar o Compose e os parceiros abrirem o endereço desse computador no navegador. Se cada parceiro iniciar os próprios containers, cada instalação terá o seu próprio banco e os dados não serão partilhados. Para acompanhar os serviços, use `docker compose logs -f`; para pará-los, use `docker compose down`.

Para desenvolvimento sem o container do frontend, o Live Server nas portas 5500 ou 5501 continua a chamar a API em `localhost:3000`. Nesse caso, mantenha essas origens em `CORS_ORIGIN` no `.env`.

## Requisitos

- Node.js 18+ ou superior
- MySQL 8+
- Git
- Navegador moderno

## 1) Preparar a base de dados

1. Crie uma base de dados chamada `angocar` no MySQL.
2. Importe o esquema SQL localizado em:

```bash
backend/database/schema.sql
```

Exemplo no MySQL:

```sql
CREATE DATABASE angocar;
USE angocar;
SOURCE backend/database/schema.sql;
```

Se preferir usar o terminal:

```bash
mysql -u root -p angocar < backend/database/schema.sql
```

## 2) Configurar as variáveis de ambiente

Acesse a pasta `backend` e copie o arquivo de exemplo:

```bash
cd backend
copy .env.example .env
```

Edite o arquivo `.env` com os seus dados locais:

```env
PORT=3000
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=sua_senha
DB_NAME=angocar
JWT_SECRET=sua_chave_secreta_muito_longa
CORS_ORIGIN=http://localhost:5500
MAX_UPLOAD_MB=25
```

> Ajuste `DB_PASSWORD` para a senha real do MySQL e `JWT_SECRET` para uma chave forte.

## 3) Instalar dependências do backend

Dentro da pasta `backend` execute:

```bash
npm install
```

## 4) Rodar a API

Inicie o servidor em modo desenvolvimento:

```bash
npm run dev
```

Se tudo estiver correto, a API ficará disponível em:

- http://localhost:3000/api

Para testar, abra no navegador:

```text
http://localhost:3000/api
```

Você deve ver uma resposta JSON com o status da API.

## 5) Rodar o frontend

O frontend é estático e pode ser servido de duas formas.

### Opção A: VS Code Live Server

- Abra a pasta do projeto no VS Code.
- Abra `frontend/index.html`.
- Use a extensão Live Server para iniciar o site.

### Opção B: servidor local via terminal

No diretório raiz do projeto:

```bash
cd frontend
python -m http.server 5500
```

Depois abra no navegador:

- http://localhost:5500/
- http://localhost:5500/admin/

## 6) Acesso ao painel administrativo

Para abrir o painel administrativo, use:

```text
http://localhost:5500/admin/
```

O painel usa a API em `http://localhost:3000/api`.

## 7) Criar o primeiro administrador

Abra `http://localhost:5500/admin/` (ou `http://localhost:8080/admin/` com Docker). Se o banco ainda não tiver administradores, o painel mostrará a opção de criar o primeiro. Depois que essa conta for criada, o cadastro inicial é bloqueado; administradores existentes podem dar permissões a outras contas no painel.

## 8) Comandos úteis

### Backend

```bash
cd backend
npm install
npm run dev
npm run build
```

### Frontend

```bash
cd frontend
python -m http.server 5500
```

## Observações

- O backend precisa do MySQL em execução.
- O frontend não deve ser aberto diretamente como `file://` em alguns casos, porque a API e a autenticação podem não funcionar corretamente.
- Use um servidor local como Live Server ou `python -m http.server` para evitar problemas de CORS e rotas.
- Não compartilhe o `.env` e mantenha a senha e o JWT em ambiente seguro.

## Estrutura principal

```text
ANGOCAR_PRO/
├── backend/
│   ├── src/
│   ├── database/
│   ├── .env
│   ├── package.json
│   └── README.md
├── frontend/
│   ├── index.html
│   ├── admin/
│   └── imagens/
├── README.md
└── .gitignore
```
