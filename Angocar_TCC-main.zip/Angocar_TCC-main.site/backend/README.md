# ANGOCAR API

API profissional em Node.js + Express + TypeScript + MySQL.

## Estrutura
- controllers/principal.controller.ts
- controllers/veiculos.controller.ts
- controllers/usuarios.controller.ts
- controllers/agendamentos.controller.ts
- servers/principal.server.ts
- servers/veiculos.server.ts
- servers/usuarios.server.ts
- servers/agendamentos.server.ts
- middlewares/auth.ts
- schemas/schemas.ts

## Instalação
1. Instale Node.js e MySQL.
2. Execute o `database/schema.sql` no MySQL.
3. Copie `.env.example` para `.env` e preencha os dados. Em `DB_PASSWORD`, coloque a palavra-passe real do MySQL; se o utilizador `root` não tiver palavra-passe, deixe vazio. Em `JWT_SECRET`, coloque uma chave longa e privada.
4. No `.env`, mantenha `CORS_ORIGIN=http://localhost:5500,http://127.0.0.1:5500` para permitir o Live Server com ambos os endereços.
5. Abra o terminal dentro da pasta `backend` e execute `npm install`, depois `npm run dev`.


## Rotas principais
GET /api
GET /api/vehicles
POST /api/usuarios
POST /api/usuarios/login
GET /api/usuarios/me (Bearer token)
PUT /api/usuarios/me (Bearer token)
POST /api/agendamentos (Bearer token)
GET /api/agendamentos/me (Bearer token)
POST /api/vehicles (admin + Bearer token)
POST /api/vehicles/:id/images (admin + Bearer token)
GET /api/vehicles/:id/images/:imageId

## Média
O vídeo principal pode ser enviado por `POST /api/media/video` como campo multipart `video`, com utilizador administrador autenticado. O frontend tenta carregar o último vídeo da tabela `midias_site` e mantém o vídeo local como fallback.


## Painel administrativo e dados dos clientes
O painel fica em `frontend/admin/index.html`. O backend MySQL fornece estas rotas, protegidas por token e função `admin`:
- `GET /api/admin/usuarios` — lista contas com nome, email, telefone, morada, função e data de criação (não inclui hashes de senha).
- `GET /api/admin/clientes/:id` — devolve os dados de um cliente e o histórico das marcações de test drive desse cliente.
- `GET /api/admin/agendamentos` — lista marcações, cliente, contacto, morada, veículo, data e estado.
- `PATCH /api/admin/agendamentos/:id` — atualiza o estado da marcação.

### Criar o primeiro administrador
Abra `http://localhost:5500/admin/` (ou `http://localhost:8080/admin/` com Docker). Enquanto não existir nenhum administrador no banco, o painel permite criar a primeira conta administradora diretamente. A verificação é sincronizada no banco para impedir que dois cadastros simultâneos criem múltiplos administradores iniciais. Após a criação, o cadastro inicial é bloqueado; um administrador autenticado pode promover outras contas pelo painel.

Se o registo falhar, verifique primeiro `http://localhost:3000/api`: deve responder com JSON e `estado: "online"`. Se indicar `database_offline`, reveja `DB_HOST`, `DB_PORT`, `DB_USER`, `DB_PASSWORD`, `DB_NAME` no `.env` e confirme que o MySQL está iniciado. Verifique também o terminal do backend para a mensagem de erro detalhada.

Não coloque senhas de clientes no painel, não partilhe credenciais administrativas e mantenha o `.env` fora do controlo de versão.
