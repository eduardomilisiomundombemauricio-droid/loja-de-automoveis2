import jwt from "jsonwebtoken";
import "dotenv/config";

function getJwtSecret(): string {
  const secret = process.env.JWT_SECRET;
  if (secret === undefined) {
    throw new Error("JWT_SECRET não configurado.");
  }
  return secret;
}

const jwtSecret = getJwtSecret();

export type AuthPayload = { id: number; nome: string; email: string; role: "user" | "admin" };

export function criarToken(payload: AuthPayload): string {
  return jwt.sign(payload, jwtSecret, { expiresIn: "7d" });
}

export function verificarToken(token: string): AuthPayload {
  const decoded = jwt.verify(token, jwtSecret);

  if (typeof decoded === "string" || typeof decoded !== "object" || decoded === null) {
    throw new Error("Token inválido.");
  }

  const { id, nome, email, role } = decoded as Partial<AuthPayload>;

  if (
    typeof id !== "number" ||
    typeof nome !== "string" ||
    typeof email !== "string" ||
    (role !== "user" && role !== "admin")
  ) {
    throw new Error("Token inválido.");
  }

  return { id, nome, email, role };
}
