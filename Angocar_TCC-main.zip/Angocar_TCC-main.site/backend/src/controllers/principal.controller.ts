import { Request, Response } from "express";
import { db } from "../utils/db";

export async function estadoApi(_req: Request, res: Response) {
  try {
    await db.query("SELECT 1");
    return res.json({ nome: "ANGOCAR API", estado: "online" });
  } catch {
    return res.status(503).json({ nome: "ANGOCAR API", estado: "database_offline" });
  }
}

export async function videoSite(req: Request, res: Response) {
  const rangeMatch = /^bytes=(\d*)-(\d*)$/.exec(req.get("range") || "");
  let item: any;
  let start = 0;
  let end = 0;

  if (rangeMatch && (rangeMatch[1] || rangeMatch[2])) {
    const [metadata] = await db.query("SELECT id, mime_type, tamanho FROM midias_site WHERE tipo = 'video' ORDER BY id DESC LIMIT 1");
    item = (metadata as any[])[0];
    if (!item) return res.status(404).json({ erro: "Vídeo do site não configurado." });
    const size = Number(item.tamanho);
    if (rangeMatch[1]) {
      start = Number(rangeMatch[1]);
      end = rangeMatch[2] ? Math.min(Number(rangeMatch[2]), size - 1) : size - 1;
    } else {
      const suffixLength = Number(rangeMatch[2]);
      if (suffixLength <= 0) return res.status(416).set("Content-Range", `bytes */${size}`).end();
      start = Math.max(size - suffixLength, 0);
      end = size - 1;
    }
    if (start >= size || start > end) {
      return res.status(416).set("Content-Range", `bytes */${size}`).end();
    }
    end = Math.min(end, start + 1024 * 1024 - 1);
    const [chunks] = await db.query("SELECT SUBSTRING(dados, ?, ?) AS dados FROM midias_site WHERE id = ?", [start + 1, end - start + 1, item.id]);
    item.dados = (chunks as any[])[0]?.dados;
  } else {
    const [rows] = await db.query("SELECT mime_type, tamanho, dados FROM midias_site WHERE tipo = 'video' ORDER BY id DESC LIMIT 1");
    item = (rows as any[])[0];
    if (!item) return res.status(404).json({ erro: "Vídeo do site não configurado." });
    end = Number(item.tamanho) - 1;
  }

  const size = Number(item.tamanho);
  res.set({ "Accept-Ranges": "bytes", "Cache-Control": "public, max-age=3600" });
  if (rangeMatch && (rangeMatch[1] || rangeMatch[2])) {
    res.status(206).set({
      "Content-Range": `bytes ${start}-${end}/${size}`,
      "Content-Length": String(end - start + 1)
    });
  } else {
    res.set("Content-Length", String(size));
  }
  res.type(item.mime_type).send(item.dados);
}

export async function uploadVideoSite(req: Request, res: Response) {
  const file = req.file;
  if (!file || !file.mimetype.startsWith("video/")) return res.status(400).json({ erro: "Envie um ficheiro de vídeo válido." });
  await db.execute("DELETE FROM midias_site WHERE tipo = 'video'");
  const [result] = await db.execute("INSERT INTO midias_site (tipo, nome_arquivo, mime_type, tamanho, dados) VALUES ('video', ?, ?, ?, ?)", [file.originalname, file.mimetype, file.size, file.buffer]);
  return res.status(201).json({ id: (result as any).insertId, nome: file.originalname });
}
