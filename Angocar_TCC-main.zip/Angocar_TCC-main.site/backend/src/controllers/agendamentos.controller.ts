import { Request, Response } from "express";
import { db } from "../utils/db";
import { agendamentoSchema } from "../schemas/schemas";

export async function criarAgendamento(req: Request, res: Response) {
  const dados = agendamentoSchema.parse(req.body);
  const [veiculo] = await db.query("SELECT id FROM veiculos WHERE id = ?", [dados.veiculo_id]);
  if (!(veiculo as any[]).length) return res.status(404).json({ erro: "Veículo não encontrado." });
  const [result] = await db.execute("INSERT INTO agendamentos (usuario_id, veiculo_id, nome, telefone, data) VALUES (?, ?, ?, ?, ?)", [req.usuario!.id, dados.veiculo_id, dados.nome, dados.telefone, dados.data]);
  return res.status(201).json({ id: (result as any).insertId, estado: "pendente" });
}

export async function meusAgendamentos(req: Request, res: Response) {
  const [rows] = await db.query(`SELECT a.id, a.nome, a.telefone, a.data, a.estado, v.id AS veiculo_id, v.marca, v.modelo FROM agendamentos a INNER JOIN veiculos v ON v.id = a.veiculo_id WHERE a.usuario_id = ? ORDER BY a.data DESC, a.id DESC`, [req.usuario!.id]);
  return res.json(rows);
}
