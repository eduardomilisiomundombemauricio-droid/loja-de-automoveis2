import { Request, Response } from "express";
import { db } from "../utils/db";
import { veiculoSchema } from "../schemas/schemas";

export async function dashboard(_req: Request, res: Response) {
  const [[usuarios]] = await db.query("SELECT COUNT(*) AS total FROM usuarios WHERE role = 'user'") as any;
  const [[veiculos]] = await db.query("SELECT COUNT(*) AS total FROM veiculos") as any;
  const [[agendamentos]] = await db.query("SELECT COUNT(*) AS total FROM agendamentos") as any;
  const [[pendentes]] = await db.query("SELECT COUNT(*) AS total FROM agendamentos WHERE estado = 'pendente'") as any;
  return res.json({ usuarios: usuarios.total, veiculos: veiculos.total, agendamentos: agendamentos.total, pendentes: pendentes.total });
}

export async function listarUsuarios(_req: Request, res: Response) {
  // Nunca devolver senha_hash ao painel administrativo.
  const [rows] = await db.query("SELECT id, nome, email, telefone, morada, role, criado_em FROM usuarios ORDER BY criado_em DESC");
  return res.json(rows);
}

export async function detalhesCliente(req: Request, res: Response) {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id < 1) return res.status(400).json({ erro: "ID do cliente inválido." });
  const [users] = await db.query(
    "SELECT id, nome, email, telefone, morada, criado_em FROM usuarios WHERE id = ? AND role = 'user'",
    [id]
  );
  const cliente = (users as any[])[0];
  if (!cliente) return res.status(404).json({ erro: "Cliente não encontrado." });
  const [bookings] = await db.query(
    "SELECT a.id, a.nome, a.telefone, a.data, a.estado, a.criado_em, v.id AS veiculo_id, v.marca, v.modelo FROM agendamentos a INNER JOIN veiculos v ON v.id = a.veiculo_id WHERE a.usuario_id = ? ORDER BY a.data DESC, a.id DESC",
    [id]
  );
  return res.json({ cliente, agendamentos: bookings });
}

export async function alterarRole(req: Request, res: Response) {
  const id = Number(req.params.id);
  const role = req.body?.role;
  if (!Number.isInteger(id) || id < 1 || !["user", "admin"].includes(role)) return res.status(400).json({ erro: "Utilizador ou função inválida." });
  if (id === req.usuario!.id && role !== "admin") return res.status(400).json({ erro: "Não pode remover a sua própria função de administrador." });
  const [result] = await db.execute("UPDATE usuarios SET role = ? WHERE id = ?", [role, id]) as any;
  if (!result.affectedRows) return res.status(404).json({ erro: "Utilizador não encontrado." });
  return res.json({ mensagem: "Função atualizada." });
}

export async function criarVeiculoAdmin(req: Request, res: Response) {
  const d = veiculoSchema.parse(req.body);
  const [result] = await db.execute("INSERT INTO veiculos (marca, modelo, ano, categoria, km, combustivel, preco, descricao) VALUES (?, ?, ?, ?, ?, ?, ?, ?)", [d.marca, d.modelo, d.ano, d.categoria, d.km || null, d.combustivel || null, d.preco, d.descricao || null]) as any;
  return res.status(201).json({ id: result.insertId, mensagem: "Veículo criado." });
}

export async function atualizarVeiculoAdmin(req: Request, res: Response) {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id < 1) return res.status(400).json({ erro: "ID inválido." });
  const d = veiculoSchema.parse(req.body);
  const [result] = await db.execute("UPDATE veiculos SET marca=?, modelo=?, ano=?, categoria=?, km=?, combustivel=?, preco=?, descricao=? WHERE id=?", [d.marca, d.modelo, d.ano, d.categoria, d.km || null, d.combustivel || null, d.preco, d.descricao || null, id]) as any;
  if (!result.affectedRows) return res.status(404).json({ erro: "Veículo não encontrado." });
  return res.json({ mensagem: "Veículo atualizado." });
}

export async function eliminarVeiculoAdmin(req: Request, res: Response) {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id < 1) return res.status(400).json({ erro: "ID inválido." });
  try {
    const [result] = await db.execute("DELETE FROM veiculos WHERE id = ?", [id]) as any;
    if (!result.affectedRows) return res.status(404).json({ erro: "Veículo não encontrado." });
    return res.json({ mensagem: "Veículo eliminado." });
  } catch {
    return res.status(409).json({ erro: "Este veículo tem agendamentos associados e não pode ser eliminado." });
  }
}

export async function listarAgendamentosAdmin(_req: Request, res: Response) {
  const [rows] = await db.query("SELECT a.id, a.usuario_id, a.nome, a.telefone, a.data, a.estado, a.criado_em, u.nome AS nome_conta, u.email, u.morada, v.marca, v.modelo FROM agendamentos a JOIN usuarios u ON u.id=a.usuario_id JOIN veiculos v ON v.id=a.veiculo_id ORDER BY a.data DESC, a.id DESC");
  return res.json(rows);
}

export async function atualizarEstadoAgendamento(req: Request, res: Response) {
  const id = Number(req.params.id);
  const estado = req.body?.estado;
  if (!Number.isInteger(id) || id < 1 || !["pendente", "confirmado", "cancelado", "concluido"].includes(estado)) return res.status(400).json({ erro: "ID ou estado inválido." });
  const [result] = await db.execute("UPDATE agendamentos SET estado=? WHERE id=?", [estado, id]) as any;
  if (!result.affectedRows) return res.status(404).json({ erro: "Agendamento não encontrado." });
  return res.json({ mensagem: "Estado do agendamento atualizado." });
}
