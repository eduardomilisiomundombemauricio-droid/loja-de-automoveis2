import { Request, Response } from "express";
import bcrypt from "bcryptjs";
import { ResultSetHeader, RowDataPacket } from "mysql2";
import { db } from "../utils/db";
import { criarToken } from "../utils/auth";
import { loginSchema, perfilSchema, registoSchema } from "../schemas/schemas";

const ADMIN_SETUP_LOCK = "angocar_initial_admin_setup";

export async function estadoSetupAdmin(_req: Request, res: Response) {
  const [rows] = await db.query<RowDataPacket[]>("SELECT COUNT(*) AS total FROM usuarios WHERE role = 'admin'");
  return res.json({ setupRequired: Number(rows[0]?.total || 0) === 0 });
}

export async function criarPrimeiroAdmin(req: Request, res: Response) {
  const dados = registoSchema.parse(req.body);
  const hash = await bcrypt.hash(dados.senha, 12);
  const connection = await db.getConnection();
  let lockAcquired = false;

  try {
    const [lockRows] = await connection.query<RowDataPacket[]>("SELECT GET_LOCK(?, 10) AS acquired", [ADMIN_SETUP_LOCK]);
    lockAcquired = Number(lockRows[0]?.acquired) === 1;
    if (!lockAcquired) return res.status(503).json({ erro: "Não foi possível iniciar a configuração. Tente novamente." });

    const [admins] = await connection.query<RowDataPacket[]>("SELECT COUNT(*) AS total FROM usuarios WHERE role = 'admin'");
    if (Number(admins[0]?.total || 0) > 0) {
      return res.status(409).json({ erro: "A configuração inicial já foi concluída. Entre com uma conta administradora." });
    }

    const [result] = await connection.execute<ResultSetHeader>(
      "INSERT INTO usuarios (nome, email, senha_hash, role) VALUES (?, ?, ?, 'admin')",
      [dados.nome, dados.email, hash]
    );
    const id = result.insertId;
    const usuario = { id, nome: dados.nome, email: dados.email, role: "admin" as const };
    const token = criarToken(usuario);
    return res.status(201).json({ token, usuario });
  } catch (error) {
    if (typeof error === "object" && error !== null && "code" in error && error.code === "ER_DUP_ENTRY") {
      return res.status(409).json({ erro: "Este email já está registado. Use outro email." });
    }
    throw error;
  } finally {
    try {
      if (lockAcquired) await connection.query("SELECT RELEASE_LOCK(?)", [ADMIN_SETUP_LOCK]);
    } finally {
      connection.release();
    }
  }
}

export async function registar(req: Request, res: Response) {
  const dados = registoSchema.parse(req.body);
  const [existente] = await db.query("SELECT id FROM usuarios WHERE email = ?", [dados.email]);
  if ((existente as any[]).length) return res.status(409).json({ erro: "Este email já está registado. Entre na sua conta ou use outro email." });
  const hash = await bcrypt.hash(dados.senha, 12);
  let result: any;
  try {
    const [insertResult] = await db.execute("INSERT INTO usuarios (nome, email, senha_hash, role) VALUES (?, ?, ?, 'user')", [dados.nome, dados.email, hash]);
    result = insertResult;
  } catch (error: any) {
    if (error?.code === "ER_DUP_ENTRY") return res.status(409).json({ erro: "Este email já está registado. Entre na sua conta ou use outro email." });
    throw error;
  }
  const id = (result as any).insertId;
  const token = criarToken({ id, nome: dados.nome, email: dados.email, role: "user" });
  return res.status(201).json({ token, usuario: { id, nome: dados.nome, email: dados.email, role: "user" } });
}

export async function login(req: Request, res: Response) {
  const dados = loginSchema.parse(req.body);
  const [rows] = await db.query("SELECT id, nome, email, senha_hash, role FROM usuarios WHERE email = ?", [dados.email]);
  const user = (rows as any[])[0];
  if (!user || !(await bcrypt.compare(dados.senha, user.senha_hash))) return res.status(401).json({ erro: "Email ou senha incorretos." });
  const token = criarToken({ id: user.id, nome: user.nome, email: user.email, role: user.role });
  return res.json({ token, usuario: { id: user.id, nome: user.nome, email: user.email, role: user.role } });
}

export async function perfil(req: Request, res: Response) {
  const [rows] = await db.query("SELECT id, nome, email, telefone, morada, role, criado_em FROM usuarios WHERE id = ?", [req.usuario!.id]);
  return res.json((rows as any[])[0] || null);
}

export async function atualizarPerfil(req: Request, res: Response) {
  const dados = perfilSchema.parse(req.body);
  await db.execute("UPDATE usuarios SET nome = ?, telefone = ?, morada = ? WHERE id = ?", [dados.nome, dados.telefone || null, dados.morada || null, req.usuario!.id]);
  return perfil(req, res);
}
