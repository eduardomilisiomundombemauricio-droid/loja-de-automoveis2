import { Request, Response } from "express";
import sharp from "sharp";
import { db } from "../utils/db";
import { veiculoSchema } from "../schemas/schemas";

const cacheImagens = new Map<string, Buffer>();
let bytesCacheImagens = 0;
const LIMITE_CACHE_IMAGENS = 64 * 1024 * 1024;

export async function listarVeiculos(_req: Request, res: Response) {
  const [rows] = await db.query("SELECT id, marca, modelo, ano, categoria, km, combustivel, preco, descricao FROM veiculos ORDER BY criado_em DESC");
  const vehicles = (rows as any[]).map(v => ({ ...v, preco: Number(v.preco), imagens: [] }));
  if (vehicles.length) {
    const ids = vehicles.map(v => v.id);
    const placeholders = ids.map(() => "?").join(", ");
    const [images] = await db.query(
      `SELECT id, veiculo_id FROM imagens_veiculos WHERE veiculo_id IN (${placeholders}) ORDER BY id`,
      ids
    );
    const imagesByVehicle = new Map<number, string[]>();
    for (const image of images as any[]) {
      const vehicleImages = imagesByVehicle.get(Number(image.veiculo_id)) || [];
      vehicleImages.push(`/api/vehicles/${image.veiculo_id}/images/${image.id}`);
      imagesByVehicle.set(Number(image.veiculo_id), vehicleImages);
    }
    for (const vehicle of vehicles) {
      vehicle.imagens = imagesByVehicle.get(Number(vehicle.id)) || [];
    }
  }
  return res.json(vehicles);
}

export async function criarVeiculo(req: Request, res: Response) {
  const dados = veiculoSchema.parse(req.body);
  const [result] = await db.execute("INSERT INTO veiculos (marca, modelo, ano, categoria, km, combustivel, preco, descricao) VALUES (?, ?, ?, ?, ?, ?, ?, ?)", [dados.marca, dados.modelo, dados.ano, dados.categoria, dados.km || null, dados.combustivel || null, dados.preco, dados.descricao || null]);
  return res.status(201).json({ id: (result as any).insertId, ...dados });
}

export async function imagemVeiculo(req: Request, res: Response) {
  const cacheKey = `${req.params.id}:${req.params.imageId}`;
  let image = cacheImagens.get(cacheKey);
  if (image) {
    cacheImagens.delete(cacheKey);
    cacheImagens.set(cacheKey, image);
  } else {
    const [rows] = await db.query("SELECT dados FROM imagens_veiculos WHERE id = ? AND veiculo_id = ?", [req.params.imageId, req.params.id]);
    const item = (rows as any[])[0];
    if (!item) return res.status(404).json({ erro: "Imagem não encontrada." });
    image = await sharp(item.dados)
      .rotate()
      .resize({ width: 1200, height: 900, fit: "inside", withoutEnlargement: true })
      .webp({ quality: 80, effort: 4 })
      .toBuffer();
    if (image.length <= LIMITE_CACHE_IMAGENS) {
      while (bytesCacheImagens + image.length > LIMITE_CACHE_IMAGENS && cacheImagens.size) {
        const oldest = cacheImagens.entries().next().value;
        if (!oldest) break;
        const [oldestId, oldestImage] = oldest;
        cacheImagens.delete(oldestId);
        bytesCacheImagens -= oldestImage.length;
      }
      cacheImagens.set(cacheKey, image);
      bytesCacheImagens += image.length;
    }
  }
  res.set("Cache-Control", "public, max-age=31536000, immutable");
  res.type("image/webp").send(image);
}

export async function uploadImagemVeiculo(req: Request, res: Response) {
  const file = req.file;
  if (!file) return res.status(400).json({ erro: "Envie uma imagem." });
  const image = await sharp(file.buffer)
    .rotate()
    .resize({ width: 1600, height: 1200, fit: "inside", withoutEnlargement: true })
    .webp({ quality: 82, effort: 4 })
    .toBuffer();
  const filename = file.originalname.replace(/\.[^.]+$/, "") + ".webp";
  const [result] = await db.execute("INSERT INTO imagens_veiculos (veiculo_id, nome_arquivo, mime_type, tamanho, dados) VALUES (?, ?, ?, ?, ?)", [req.params.id, filename, "image/webp", image.length, image]);
  return res.status(201).json({ id: (result as any).insertId });
}
