import { NextFunction, Request, Response } from "express";
import { verificarToken, AuthPayload } from "../utils/auth";

declare global {
  namespace Express { interface Request { usuario?: AuthPayload } }
}

export function exigirLogin(req: Request, res: Response, next: NextFunction) {
  const header = req.headers.authorization;
  const token = header?.startsWith("Bearer ") ? header.slice(7) : null;
  if (!token) return res.status(401).json({ erro: "Autenticação necessária." });
  try {
    req.usuario = verificarToken(token);
    next();
  } catch {
    return res.status(401).json({ erro: "Token inválido ou expirado." });
  }
}

export function exigirAdmin(req: Request, res: Response, next: NextFunction) {
  if (req.usuario?.role !== "admin") return res.status(403).json({ erro: "Acesso de administrador necessário." });
  next();
}
