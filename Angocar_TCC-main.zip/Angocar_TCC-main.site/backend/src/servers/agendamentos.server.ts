import { Router } from "express";
import { criarAgendamento, meusAgendamentos } from "../controllers/agendamentos.controller";
import { exigirLogin } from "../middlewares/auth";
export const agendamentosRouter = Router();
agendamentosRouter.post("/", exigirLogin, criarAgendamento);
agendamentosRouter.get("/me", exigirLogin, meusAgendamentos);
