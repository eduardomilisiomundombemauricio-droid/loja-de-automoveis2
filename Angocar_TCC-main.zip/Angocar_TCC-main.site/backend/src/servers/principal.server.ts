import { Router } from "express";
import { rateLimit } from "express-rate-limit";
import multer from "multer";
import { estadoApi, videoSite, uploadVideoSite } from "../controllers/principal.controller";
import { exigirAdmin, exigirLogin } from "../middlewares/auth";

const mediaRateLimit = rateLimit({ windowMs: 15 * 60 * 1000, limit: 900, standardHeaders: "draft-8", legacyHeaders: false });
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: Number(process.env.MAX_UPLOAD_MB || 25) * 1024 * 1024 },
  fileFilter: (_req, file, cb) => cb(null, file.mimetype.startsWith("video/"))
});

export const principalRouter = Router();
principalRouter.get("/", estadoApi);
principalRouter.get("/media/video", mediaRateLimit, videoSite);
principalRouter.post("/media/video", exigirLogin, exigirAdmin, upload.single("video"), uploadVideoSite);
