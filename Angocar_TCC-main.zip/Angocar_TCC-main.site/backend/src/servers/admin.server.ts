import { Router } from "express";
import { exigirAdmin, exigirLogin } from "../middlewares/auth";
import { dashboard, listarUsuarios, detalhesCliente, alterarRole, criarVeiculoAdmin, atualizarVeiculoAdmin, eliminarVeiculoAdmin, listarAgendamentosAdmin, atualizarEstadoAgendamento } from "../controllers/admin.controller";

export const adminRouter = Router();
adminRouter.use(exigirLogin, exigirAdmin);
adminRouter.get("/dashboard", dashboard);
adminRouter.get("/usuarios", listarUsuarios);
adminRouter.get("/clientes/:id", detalhesCliente);
adminRouter.patch("/usuarios/:id/role", alterarRole);
adminRouter.post("/veiculos", criarVeiculoAdmin);
adminRouter.put("/veiculos/:id", atualizarVeiculoAdmin);
adminRouter.delete("/veiculos/:id", eliminarVeiculoAdmin);
adminRouter.get("/agendamentos", listarAgendamentosAdmin);
adminRouter.patch("/agendamentos/:id", atualizarEstadoAgendamento);
