import { z } from "zod";

export const registoSchema = z.object({ nome: z.string().trim().min(2, "O nome deve ter pelo menos 2 caracteres.").max(120), email: z.string().trim().toLowerCase().email("Introduza um email válido.").max(180), senha: z.string().min(8, "A palavra-passe deve ter pelo menos 8 caracteres.").max(100) });
export const loginSchema = z.object({ email: z.string().trim().toLowerCase().email("Introduza um email válido."), senha: z.string().min(1).max(100) });
export const perfilSchema = z.object({ nome: z.string().trim().min(2).max(120), telefone: z.string().trim().max(30).optional(), morada: z.string().trim().max(255).optional() });
export const veiculoSchema = z.object({ marca: z.string().trim().min(1).max(80), modelo: z.string().trim().min(1).max(100), ano: z.coerce.number().int().min(1900).max(2100), categoria: z.string().trim().min(1).max(50), km: z.string().max(50).optional(), combustivel: z.string().max(50).optional(), preco: z.coerce.number().nonnegative(), descricao: z.string().max(5000).optional() });
export const agendamentoSchema = z.object({ veiculo_id: z.coerce.number().int().positive(), nome: z.string().trim().min(2).max(120), telefone: z.string().trim().min(6).max(30), data: z.string().regex(/^\d{4}-\d{2}-\d{2}$/) });
