import express from "express";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import "dotenv/config";
import { principalRouter } from "./servers/principal.server";
import { veiculosRouter } from "./servers/veiculos.server";
import { usuariosRouter } from "./servers/usuarios.server";
import { agendamentosRouter } from "./servers/agendamentos.server";
import { adminRouter } from "./servers/admin.server";
import { errorHandler } from "./middlewares/error";

const app = express();
const port = Number(process.env.PORT || 3000);
const configuredOrigins = (process.env.CORS_ORIGIN || "http://localhost:5500,http://127.0.0.1:5500").split(",").map(v => v.trim()).filter(Boolean);
const localOrigins = new Set([
  "http://localhost:5500",
  "http://127.0.0.1:5500",
  "http://localhost:5501",
  "http://127.0.0.1:5501",
  "http://localhost:8080",
  "http://127.0.0.1:8080"
]);
const allowedOrigins = new Set([...configuredOrigins, ...localOrigins]);

app.use(helmet({ crossOriginResourcePolicy: { policy: "cross-origin" } }));
app.use(cors({
  origin(origin, callback) {
    // Requests sem Origin incluem testes locais e chamadas de ferramentas de desenvolvimento.
    if (!origin || allowedOrigins.has(origin)) return callback(null, true);
    return callback(new Error(`Origem não autorizada pelo CORS: ${origin}`));
  },
  credentials: false
}));
app.use(rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 300,
  standardHeaders: "draft-8",
  legacyHeaders: false,
  skip: req => req.method === "GET" && (/^\/api\/media\/video$/.test(req.path) || /^\/api\/vehicles\/\d+\/images\/\d+$/.test(req.path))
}));
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: true, limit: "1mb" }));

app.use("/api", principalRouter);
app.use("/api/vehicles", veiculosRouter);
app.use("/api/usuarios", usuariosRouter);
app.use("/api/agendamentos", agendamentosRouter);
app.use("/api/admin", adminRouter);

app.use(errorHandler);

app.listen(port, () => console.log(`ANGOCAR API em http://localhost:${port}`));
